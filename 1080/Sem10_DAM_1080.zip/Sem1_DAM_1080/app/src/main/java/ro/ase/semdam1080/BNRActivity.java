package ro.ase.semdam1080;

import android.app.Activity;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;

import ro.ase.semdam1080.network.Network;

public class BNRActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bnr);

        Log.e("lifecycle", "apel onCreate()");

        Button btn2 = new Button(this);

        TextView tvData = findViewById(R.id.tvDataCurs);
        EditText etEUR = findViewById(R.id.editTextEUR);
        EditText etUSD = findViewById(R.id.editTextUSD);
        EditText etGBP = findViewById(R.id.editTextGBP);
        EditText etXAU = findViewById(R.id.editTextXAU);

        Button btnAfisare = findViewById(R.id.btnAfisare);

        btnAfisare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /*Toast.makeText(getApplicationContext(),"Salut!",
                        Toast.LENGTH_LONG).show();*/
               /* tvData.setText("2022-10-04");
                etEUR.setText("4.9455");
                etUSD.setText("5.2134");
                etGBP.setText("5.5678");
                etXAU.setText("251.3456");*/
                Network network = new Network()
                {
                    @Override
                    protected void onPostExecute(InputStream inputStream) {

                        tvData.setText(cv.getDataCurs());
                        etEUR.setText(cv.getValEuro());
                        etUSD.setText(cv.getValDolar());
                        etGBP.setText(cv.getValLira());
                        etXAU.setText(cv.getValAur());
                    }
                };
                try {
                    network.execute(new URL("https://www.bnr.ro/nbrfxrates.xml"));
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                }
            }
        });

        Button btnSalvare = findViewById(R.id.btnSalvare);
        btnSalvare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CursValutar cursValutar = new CursValutar(tvData.getText().toString(),
                        etEUR.getText().toString(),
                        etUSD.getText().toString(),
                        etGBP.getText().toString(),
                        etXAU.getText().toString());

                try {
                    scrieFisier("fisier.dat", cursValutar);
                    cursValutar = null;
                    cursValutar = citesteFisier("fisier.dat");
                    Toast.makeText(getApplicationContext(), cursValutar.toString(),
                            Toast.LENGTH_LONG).show();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    private void scrieFisier(String numeFisier, CursValutar cv) throws IOException {

        FileOutputStream fileOutputStream = openFileOutput(numeFisier, Activity.MODE_PRIVATE);
        DataOutputStream dos = new DataOutputStream(fileOutputStream);
        dos.writeUTF(cv.getDataCurs());
        dos.writeUTF(cv.getValEuro());
        dos.writeUTF(cv.getValDolar());
        dos.writeUTF(cv.getValLira());
        dos.writeUTF(cv.getValAur());
        dos.flush();
        fileOutputStream.close();
    }

    private CursValutar citesteFisier(String numeFisier) throws IOException
    {
        FileInputStream fileInputStream = openFileInput(numeFisier);
        DataInputStream dis = new DataInputStream(fileInputStream);
        String data = dis.readUTF();
        String euro = dis.readUTF();
        String dolar = dis.readUTF();
        String lira  =dis.readUTF();
        String aur = dis.readUTF();
        CursValutar cv = new CursValutar(data, euro, dolar, lira, aur);
        fileInputStream.close();
        return cv;
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.e("lifecycle", "apel onStart()");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.e("lifecycle", "apel onResume()");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.e("lifecycle", "apel onPause()");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.e("lifecycle", "apel onStop()");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.e("lifecycle", "apel onRestart()");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.e("lifecycle", "apel onDestroy()");
    }
}