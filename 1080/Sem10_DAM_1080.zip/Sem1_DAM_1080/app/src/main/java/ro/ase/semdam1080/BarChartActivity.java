package ro.ase.semdam1080;

import androidx.appcompat.app.AppCompatActivity;
import ro.ase.semdam1080.graphics.BarChartView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.LinearLayout;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BarChartActivity extends AppCompatActivity {

    ArrayList<Student> list;
    LinearLayout layout;
    Map<String, Integer> source;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bar_chart);

        Intent intent = getIntent();
        list = (ArrayList<Student>)intent.getSerializableExtra("list");

        source = getSource(list);

        layout = findViewById(R.id.layoutBar);
        layout.addView(new BarChartView(getApplicationContext(), source));
    }

    private Map<String, Integer> getSource(List<Student> studentList)
    {
        if(studentList==null || studentList.isEmpty())
            return new HashMap<>();
        else
        {
            Map<String, Integer> results = new HashMap<>();
            for(Student student: studentList)
                if(results.containsKey(student.getFacultate()))
                    results.put(student.getFacultate(), results.get(student.getFacultate())+1);
            else
                    results.put(student.getFacultate(), 1);
            return results;
        }
    }
}