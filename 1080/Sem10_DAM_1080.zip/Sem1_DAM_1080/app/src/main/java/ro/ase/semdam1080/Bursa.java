package ro.ase.semdam1080;

import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

@Entity(tableName = "burse")
public class Bursa {

    @PrimaryKey(autoGenerate = true)
    private int id;
    private String tipBursa;
    private int valoareBursa;

    @Ignore
    public Bursa(int id, String tipBursa, int valoareBursa) {
        this.id = id;
        this.tipBursa = tipBursa;
        this.valoareBursa = valoareBursa;
    }

    public Bursa(String tipBursa, int valoareBursa) {
        this.tipBursa = tipBursa;
        this.valoareBursa = valoareBursa;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTipBursa() {
        return tipBursa;
    }

    public void setTipBursa(String tipBursa) {
        this.tipBursa = tipBursa;
    }

    public int getValoareBursa() {
        return valoareBursa;
    }

    public void setValoareBursa(int valoareBursa) {
        this.valoareBursa = valoareBursa;
    }

    @Override
    public String toString() {
        return "Bursa{" +
                "id=" + id +
                ", tipBursa='" + tipBursa + '\'' +
                ", valoareBursa=" + valoareBursa +
                '}';
    }
}
