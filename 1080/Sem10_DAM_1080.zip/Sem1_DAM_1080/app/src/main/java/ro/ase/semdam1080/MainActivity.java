package ro.ase.semdam1080;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import ro.ase.semdam1080.database.StudentiDB;
import ro.ase.semdam1080.network.ExtractJSON;
import ro.ase.semdam1080.network.ExtractXML;

public class MainActivity extends AppCompatActivity {

    private Intent intent;

    public static final int REQUEST_CODE_ADD = 200;
    public static final int REQUEST_CODE_EDIT = 300;

    public static final String EDIT_STUDENT = "editStudent";

    public int poz;

    List<Student> listaStudenti = new ArrayList<>();

    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FloatingActionButton btn = findViewById(R.id.floatingActionButton);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), AddActivity.class);
                startActivityForResult(intent, REQUEST_CODE_ADD);
            }
        });

        listView = findViewById(R.id.listView);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {

                poz = position;
                intent = new Intent(getApplicationContext(), AddActivity.class);
                intent.putExtra(EDIT_STUDENT, listaStudenti.get(position));
                startActivityForResult(intent, REQUEST_CODE_EDIT);
            }
        });

        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int position, long id) {

                Student student = listaStudenti.get(position);
                CustomAdapter adapter = (CustomAdapter) listView.getAdapter();

                AlertDialog dialog = new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Confirmare stergere")
                        .setMessage("Doriti sa stergeti?")
                        .setNegativeButton("NU", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Toast.makeText(getApplicationContext(),
                                        "Nu am sters nimic!", Toast.LENGTH_LONG).show();
                                dialogInterface.cancel();
                            }
                        })
                        .setPositiveButton("DA", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                listaStudenti.remove(student);
                                adapter.notifyDataSetChanged();

                                StudentiDB studentiDB = StudentiDB.getInstanta(getApplicationContext());
                                studentiDB.getStudentDao().delete(student);

                                Toast.makeText(getApplicationContext(),
                                        "Am sters "+student.toString(), Toast.LENGTH_LONG).show();
                                dialogInterface.cancel();
                            }
                        }).create();
                dialog.show();

                return true;
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode==REQUEST_CODE_ADD && resultCode==RESULT_OK && data!=null)
        {
            Student student = (Student) data.getSerializableExtra(AddActivity.ADD_STUDENT);
            if(student!=null)
            {
                //listaStudenti.add(student);
                /*ArrayAdapter<Student> adapter = new ArrayAdapter<>(getApplicationContext(),
                        android.R.layout.simple_list_item_1,
                        listaStudenti);*/

                StudentiDB database = StudentiDB.getInstanta(getApplicationContext());
                Bursa bursa = new Bursa("Bursa de merit", 1000);
                long id = database.getBursaDao().insert(bursa);
                student.setIdBursa((int)id);
                database.getStudentDao().insert(student);

                listaStudenti = database.getStudentDao().getAll();

                CustomAdapter adapter = new CustomAdapter(getApplicationContext(),
                        R.layout.elem_listview, listaStudenti, getLayoutInflater())
                {
                    @NonNull
                    @Override
                    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                        View view = super.getView(position, convertView, parent);

                        Student student1 = listaStudenti.get(position);
                        TextView tvMedie = view.findViewById(R.id.tvMedie);
                        if(student1.getMedieAnuala()>=5)
                            tvMedie.setTextColor(Color.GREEN);
                        else
                            tvMedie.setTextColor(Color.RED);

                        return view;
                    }
                };
                listView.setAdapter(adapter);
            }
        }
        else
        if(requestCode==REQUEST_CODE_EDIT && resultCode==RESULT_OK && data!=null) {
            Student student = (Student) data.getSerializableExtra(AddActivity.ADD_STUDENT);
            if (student != null) {
                listaStudenti.get(poz).setNumeStudent(student.getNumeStudent());
                listaStudenti.get(poz).setDataNasterii(student.getDataNasterii());
                listaStudenti.get(poz).setFacultate(student.getFacultate());
                listaStudenti.get(poz).setMedieAnuala(student.getMedieAnuala());
                listaStudenti.get(poz).setAnStudiu(student.getAnStudiu());

                StudentiDB database = StudentiDB.getInstanta(getApplicationContext());
                database.getStudentDao().update(student);

               /* ArrayAdapter<Student> adapter = new ArrayAdapter<>(getApplicationContext(),
                        android.R.layout.simple_list_item_1,
                        listaStudenti);*/
                CustomAdapter adapter = new CustomAdapter(getApplicationContext(),
                        R.layout.elem_listview, listaStudenti, getLayoutInflater())
                {
                    @NonNull
                    @Override
                    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                        View view = super.getView(position, convertView, parent);

                        Student student1 = listaStudenti.get(position);
                        TextView tvMedie = view.findViewById(R.id.tvMedie);
                        if(student1.getMedieAnuala()>=5)
                            tvMedie.setTextColor(Color.GREEN);
                        else
                            tvMedie.setTextColor(Color.RED);

                        return view;
                    }
                };
                listView.setAdapter(adapter);
            }
        }
    }

    @Override
    protected void onStart() {
        super.onStart();

        StudentiDB studentiDB = StudentiDB.getInstanta(getApplicationContext());
        if(listaStudenti.size() == 0)
            listaStudenti = studentiDB.getStudentDao().getAll();

        CustomAdapter adapter = new CustomAdapter(getApplicationContext(), R.layout.elem_listview,
                listaStudenti, getLayoutInflater())
        {
            @NonNull
            @Override
            public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                View view = super.getView(position, convertView, parent);

                Student student1 = listaStudenti.get(position);

                TextView tvMedie = view.findViewById(R.id.tvMedie);
                if(student1.getMedieAnuala() >= 5)
                    tvMedie.setTextColor(Color.GREEN);
                else
                    tvMedie.setTextColor(Color.RED);

                return view;
            }
        };
        listView.setAdapter(adapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.meniu_principal, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId())
        {
            case R.id.optiune1:
                Intent intent1 = new Intent(this, BNRActivity.class);
                startActivity(intent1);
                break;
            case R.id.optiune2:

                ExtractXML extractXML = new ExtractXML()
                {
                    @Override
                    protected void onPostExecute(InputStream inputStream) {

                        listaStudenti.addAll(studentList);

                        StudentiDB studentiDB = StudentiDB.getInstanta(getApplicationContext());

                        Bursa bursa = new Bursa("Bursa de performanta", 1500);
                        long id = studentiDB.getBursaDao().insert(bursa);
                        for(Student student: this.studentList)
                            student.setIdBursa((int)id);
                        studentiDB.getStudentDao().insert(this.studentList);

                        CustomAdapter adapter = new CustomAdapter(getApplicationContext(),
                                R.layout.elem_listview, listaStudenti, getLayoutInflater())
                        {
                            @NonNull
                            @Override
                            public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                                View view = super.getView(position, convertView, parent);

                                Student student1 = listaStudenti.get(position);
                                TextView tvMedie = view.findViewById(R.id.tvMedie);
                                if(student1.getMedieAnuala()>=5)
                                    tvMedie.setTextColor(Color.GREEN);
                                else
                                    tvMedie.setTextColor(Color.RED);

                                return view;
                            }
                        };
                        listView.setAdapter(adapter);
                    }
                };
                try {
                    extractXML.execute(new URL("https://pastebin.com/raw/nPLdVfTZ"));
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                }
                break;
            case R.id.optiune3:

                ExtractJSON extractJSON = new ExtractJSON(){

                    ProgressDialog progressDialog;

                    @Override
                    protected void onPreExecute() {
                        progressDialog = new ProgressDialog(MainActivity.this);
                        progressDialog.setMessage("Please wait...");
                        progressDialog.show();
                    }

                    @Override
                    protected void onPostExecute(String s) {

                        progressDialog.cancel();

                        listaStudenti.addAll(studentListJSON);

                        StudentiDB studentiDB = StudentiDB.getInstanta(getApplicationContext());
                        Bursa bursa = new Bursa("Bursa de excelenta", 1800);
                        long id = studentiDB.getBursaDao().insert(bursa);
                        for(Student student: this.studentListJSON)
                            student.setIdBursa((int)id);
                        studentiDB.getStudentDao().insert(this.studentListJSON);

                        CustomAdapter adapter = new CustomAdapter(getApplicationContext(),
                                R.layout.elem_listview, listaStudenti, getLayoutInflater())
                        {
                            @NonNull
                            @Override
                            public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                                View view = super.getView(position, convertView, parent);

                                Student student1 = listaStudenti.get(position);
                                TextView tvMedie = view.findViewById(R.id.tvMedie);
                                if(student1.getMedieAnuala()>=5)
                                    tvMedie.setTextColor(Color.GREEN);
                                else
                                    tvMedie.setTextColor(Color.RED);

                                return view;
                            }
                        };
                        listView.setAdapter(adapter);
                    }
                };
                try {
                    extractJSON.execute(new URL("https://pastebin.com/raw/CgC1rv40"));
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                }
                break;
            case R.id.optiune4:
                Intent intent2 = new Intent(this, ViewBDActivity.class);
                startActivity(intent2);
                break;
            case R.id.optiune5:
                Intent intent3 = new Intent(this, BarChartActivity.class);
                intent3.putExtra("list", (ArrayList)listaStudenti);
                startActivity(intent3);

                return true;
        }
        return false;
    }
}