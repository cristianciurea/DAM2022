package ro.ase.semdam1080;

import androidx.appcompat.app.AppCompatActivity;
import ro.ase.semdam1080.database.StudentiDB;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.util.List;

public class ViewBDActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        HorizontalScrollView sv = new HorizontalScrollView(this);
        LinearLayout ll = new LinearLayout(this);
        ll.setOrientation(LinearLayout.VERTICAL);

        ListView lv = new ListView(this);

        StudentiDB database = StudentiDB.getInstanta(getApplicationContext());
        List<Bursa> listaBurse = database.getBursaDao().getAll();

        ArrayAdapter<Bursa> adapter = new ArrayAdapter<>(getApplicationContext(),
                android.R.layout.simple_list_item_1, listaBurse);

        lv.setAdapter(adapter);

        TextView tv1 = new TextView(this);
        tv1.setText("Lista burselor din baza de date: +\n");

        ll.addView(tv1);
        ll.addView(lv);
        sv.addView(ll);

        setContentView(sv);
    }
}