package ro.ase.semdam1080.database;

import java.util.List;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import ro.ase.semdam1080.Bursa;

@Dao
public interface BursaDao {

    @Insert
    long insert(Bursa bursa);

    @Query("select * from burse")
    List<Bursa> getAll();

    @Query("delete from burse")
    void deleteAll();
}
