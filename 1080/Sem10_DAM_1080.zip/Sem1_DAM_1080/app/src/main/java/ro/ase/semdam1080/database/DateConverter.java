package ro.ase.semdam1080.database;

import java.util.Date;

import androidx.room.TypeConverter;

public class DateConverter {

    @TypeConverter
    public Date fromTimeStamp(Long value)
    {
        return value==null? null: new Date(value);
    }

    @TypeConverter
    public Long dateToTimestamp(Date date)
    {
        if(date==null)
            return null;
        else
            return date.getTime();
    }
}
