package ro.ase.semdam1080;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

public class AddActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        String[] facultati = {"CSIE", "CIG", "FABIZ", "REI"};
        ArrayAdapter<String> adaptor = new ArrayAdapter<>(getApplicationContext(),
                android.support.design.R.layout.support_simple_spinner_dropdown_item,
                facultati);
        Spinner spinner = findViewById(R.id.spinner);
        spinner.setAdapter(adaptor);
    }
}