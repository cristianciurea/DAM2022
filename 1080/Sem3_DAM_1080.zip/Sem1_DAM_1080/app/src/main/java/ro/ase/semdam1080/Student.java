package ro.ase.semdam1080;

import java.util.Date;

public class Student {

    private String numeStudent;
    private Date dataNasterii;
    private String facultate;//CSIE, CIG, FABIZ, etc.
    private float medieAnuala;
    private String anStudiu; //1, 2 sau 3

    public Student(String numeStudent, Date dataNasterii, String facultate, float medieAnuala, String anStudiu) {
        this.numeStudent = numeStudent;
        this.dataNasterii = dataNasterii;
        this.facultate = facultate;
        this.medieAnuala = medieAnuala;
        this.anStudiu = anStudiu;
    }

    public String getNumeStudent() {
        return numeStudent;
    }

    public void setNumeStudent(String numeStudent) {
        this.numeStudent = numeStudent;
    }

    public Date getDataNasterii() {
        return dataNasterii;
    }

    public void setDataNasterii(Date dataNasterii) {
        this.dataNasterii = dataNasterii;
    }

    public String getFacultate() {
        return facultate;
    }

    public void setFacultate(String facultate) {
        this.facultate = facultate;
    }

    public float getMedieAnuala() {
        return medieAnuala;
    }

    public void setMedieAnuala(float medieAnuala) {
        this.medieAnuala = medieAnuala;
    }

    public String getAnStudiu() {
        return anStudiu;
    }

    public void setAnStudiu(String anStudiu) {
        this.anStudiu = anStudiu;
    }

    @Override
    public String toString() {
        return "Student{" +
                "numeStudent='" + numeStudent + '\'' +
                ", dataNasterii=" + dataNasterii +
                ", facultate='" + facultate + '\'' +
                ", medieAnuala=" + medieAnuala +
                ", anStudiu='" + anStudiu + '\'' +
                '}';
    }
}
