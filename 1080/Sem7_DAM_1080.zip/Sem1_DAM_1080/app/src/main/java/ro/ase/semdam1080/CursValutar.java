package ro.ase.semdam1080;

public class CursValutar {

    private String dataCurs;
    private String valEuro;
    private String valDolar;
    private String valLira;
    private String valAur;

    public CursValutar(){}

    public CursValutar(String dataCurs, String valEuro, String valDolar, String valLira, String valAur) {
        this.dataCurs = dataCurs;
        this.valEuro = valEuro;
        this.valDolar = valDolar;
        this.valLira = valLira;
        this.valAur = valAur;
    }

    public String getDataCurs() {
        return dataCurs;
    }

    public void setDataCurs(String dataCurs) {
        this.dataCurs = dataCurs;
    }

    public String getValEuro() {
        return valEuro;
    }

    public void setValEuro(String valEuro) {
        this.valEuro = valEuro;
    }

    public String getValDolar() {
        return valDolar;
    }

    public void setValDolar(String valDolar) {
        this.valDolar = valDolar;
    }

    public String getValLira() {
        return valLira;
    }

    public void setValLira(String valLira) {
        this.valLira = valLira;
    }

    public String getValAur() {
        return valAur;
    }

    public void setValAur(String valAur) {
        this.valAur = valAur;
    }

    @Override
    public String toString() {
        return "CursValutar{" +
                "dataCurs='" + dataCurs + '\'' +
                ", valEuro='" + valEuro + '\'' +
                ", valDolar='" + valDolar + '\'' +
                ", valLira='" + valLira + '\'' +
                ", valAur='" + valAur + '\'' +
                '}';
    }
}
