package ro.ase.semdam1080.network;

import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import ro.ase.semdam1080.Student;

public class ExtractJSON extends AsyncTask<URL, Void, String> {

    public List<Student> studentListJSON = new ArrayList<>();

    @Override
    protected String doInBackground(URL... urls) {

        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) urls[0].openConnection();
            conn.setRequestMethod("GET");
            InputStream ist = conn.getInputStream();

            InputStreamReader isr = new InputStreamReader(ist);
            BufferedReader br = new BufferedReader(isr);
            String linie = null;
            String rezultat = "";
            while ((linie = br.readLine())!=null)
                rezultat+= linie;

            //parsare JSON
            parsareJSON(rezultat);

            return rezultat;

        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

    public void parsareJSON(String str)
    {
        if(str!=null)
        {
            JSONObject jsonObject = null;
            try {
                jsonObject = new JSONObject(str);
                JSONArray studenti = jsonObject.getJSONArray("studenti");
                for(int i=0;i<studenti.length();i++)
                {
                    JSONObject obj = studenti.getJSONObject(i);
                    String nume = obj.getString("Nume");
                    Date dataNasterii = new Date(obj.getString("DataNasterii"));
                    String facultate = obj.getString("Facultate");
                    float medie = Float.parseFloat(obj.getString("Medie"));
                    String anStudiu = obj.getString("AnStudiu");

                    Student student = new Student(nume, dataNasterii, facultate, medie, anStudiu);
                    studentListJSON.add(student);
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        else
            Log.e("parsareJSON", "JSON este null!");
    }
}
