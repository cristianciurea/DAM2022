package ro.ase.semdam1080.database;

import java.util.List;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import ro.ase.semdam1080.Student;

@Dao
public interface StudentDAO {

    @Insert
    void insert(Student student);

    @Insert
    void insert(List<Student> studentList);

    @Query("select * from studenti")
    List<Student> getAll();

    @Delete
    void delete(Student student);

    @Update
    void update(Student student);
}
