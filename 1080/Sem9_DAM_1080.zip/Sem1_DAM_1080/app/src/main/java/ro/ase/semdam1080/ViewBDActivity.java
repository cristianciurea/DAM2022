package ro.ase.semdam1080;

import androidx.appcompat.app.AppCompatActivity;
import ro.ase.semdam1080.database.StudentiDB;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.util.List;

public class ViewBDActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        HorizontalScrollView sv = new HorizontalScrollView(this);
        LinearLayout ll = new LinearLayout(this);
        ll.setOrientation(LinearLayout.VERTICAL);

        ListView lv = new ListView(this);

        StudentiDB database = StudentiDB.getInstanta(getApplicationContext());
        List<Student> listaStud = database.getStudentDao().getAll();

        ArrayAdapter<Student> adapter = new ArrayAdapter<>(getApplicationContext(),
                android.R.layout.simple_list_item_1, listaStud);

        lv.setAdapter(adapter);

        TextView tv1 = new TextView(this);
        tv1.setText("Lista studentilor din baza de date: +\n");

        TextView tv2 = new TextView(this);
        tv2.setText("ID  nume  data   facultate  medie  idBursa");

        ll.addView(tv1);
        ll.addView(tv2);
        ll.addView(lv);
        sv.addView(ll);

        setContentView(sv);
    }
}