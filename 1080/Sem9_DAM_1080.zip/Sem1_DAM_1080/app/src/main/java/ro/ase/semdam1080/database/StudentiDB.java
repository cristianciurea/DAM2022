package ro.ase.semdam1080.database;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;
import ro.ase.semdam1080.Bursa;
import ro.ase.semdam1080.Student;

@Database(entities = {Student.class, Bursa.class}, version = 2, exportSchema = false)
@TypeConverters({DateConverter.class})
public abstract class StudentiDB extends RoomDatabase {

    public static final String DB_NAME = "studenti.db";
    public static StudentiDB instanta;

    public static StudentiDB getInstanta(Context context)
    {
        if(instanta==null)
            instanta = Room.databaseBuilder(context, StudentiDB.class,
                    DB_NAME)
                    .allowMainThreadQueries()
                    .fallbackToDestructiveMigration()
                    .build();
        return instanta;
    }

    public abstract StudentDAO getStudentDao();

    public abstract BursaDao getBursaDao();
}
