package ro.ase.sem1mad1098;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AddActivity extends AppCompatActivity {

    public static final String ADD_STUDENT = "addStudent";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        Intent intent = getIntent();

        String[] faculties = {"CSIE", "REI", "FABIZ", "MRK"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(getApplicationContext(),
                android.support.design.R.layout.support_simple_spinner_dropdown_item,
                faculties);
        Spinner spinner = findViewById(R.id.spinner);
        spinner.setAdapter(adapter);

        EditText etStudentName = findViewById(R.id.editTextStudentName);
        EditText etBirthDate = findViewById(R.id.editTextDate);
        EditText etAverageGrade = findViewById(R.id.editTextAverageGrade);
        RadioGroup radioGroup = findViewById(R.id.radioGroup);

        Button btnCreate = findViewById(R.id.btnCreate);
        btnCreate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(etStudentName.getText().toString().isEmpty())
                    etStudentName.setError("Please insert the name!");
                else
                    if(etBirthDate.getText().toString().isEmpty())
                        etBirthDate.setError("Please type the birth date!");
                    else
                        if(etAverageGrade.getText().toString().isEmpty())
                            etAverageGrade.setError("Please enter the grade!");
                        else
                        {
                            SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy",
                                    Locale.US);
                            try {
                                sdf.parse(etBirthDate.getText().toString());
                                Date birthDate = new Date(etBirthDate.getText().toString());
                                String name = etStudentName.getText().toString();
                                String faculty = spinner.getSelectedItem().toString();
                                float averageGrade = Float.parseFloat(etAverageGrade.getText().toString());
                                RadioButton radioButton = findViewById(radioGroup.getCheckedRadioButtonId());
                                String yearOfStudy = radioButton.getText().toString();

                                Student student = new Student(name, birthDate, faculty, averageGrade, yearOfStudy);
                                //Toast.makeText(getApplicationContext(), student.toString(), Toast.LENGTH_LONG).show();
                                intent.putExtra(ADD_STUDENT, student);
                                setResult(RESULT_OK, intent);
                                finish();
                            }
                            catch (Exception ex)
                            {
                                ex.printStackTrace();
                                Toast.makeText(getApplicationContext(),
                                        "Invalid date!", Toast.LENGTH_LONG).show();
                            }
                        }
            }
        });
    }
}