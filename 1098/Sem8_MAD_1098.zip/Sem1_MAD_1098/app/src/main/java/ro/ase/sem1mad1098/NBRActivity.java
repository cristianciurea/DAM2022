package ro.ase.sem1mad1098;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;

import ro.ase.sem1mad1098.database.FXRatesDB;
import ro.ase.sem1mad1098.network.Network;

public class NBRActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nbr);

        TextView tvDate = findViewById(R.id.tvDate);
        //TextView tv1 = new TextView(this);
        EditText etEUR = findViewById(R.id.editTextEUR);
        EditText etUSD = findViewById(R.id.editTextUSD);
        EditText etGBP = findViewById(R.id.editTextGBP);
        EditText etXAU = findViewById(R.id.editTextXAU);

        Button btnShow = findViewById(R.id.btnShow);
        Button btnSave = findViewById(R.id.btnSave);

        btnShow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /*etEUR.setText("4.9456");
                etUSD.setText("5.0130");
                etGBP.setText("5.5678");
                etXAU.setText("256.7890");*/
                Network network = new Network()
                {
                    @Override
                    protected void onPostExecute(InputStream inputStream) {

                        tvDate.setText(fxRate.getDate());
                        etEUR.setText(fxRate.getEuro());
                        etUSD.setText(fxRate.getDolar());
                        etGBP.setText(fxRate.getPound());
                        etXAU.setText(fxRate.getGold());
                    }
                };
                try {
                    network.execute(new URL("https://www.bnr.ro/nbrfxrates.xml"));
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                }
            }
        });

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                FXRate fxRate = new FXRate(tvDate.getText().toString(),
                        etEUR.getText().toString(),
                        etUSD.getText().toString(),
                        etGBP.getText().toString(),
                        etXAU.getText().toString());

                try {
                    writeDataInFile("file.dat", fxRate);
                    fxRate = null;
                    fxRate = readDataFromFile("file.dat");
                    Toast.makeText(getApplicationContext(),
                            fxRate.toString(), Toast.LENGTH_LONG).show();
                } catch (IOException e) {
                    e.printStackTrace();
                }

                FXRatesDB database = FXRatesDB.getInstance(getApplicationContext());
                database.getFXRatesDao().insert(fxRate);
                Toast.makeText(getApplicationContext(),
                        "Saved into database!", Toast.LENGTH_LONG).show();
            }
        });
    }

    private void writeDataInFile(String fileName, FXRate fxRate) throws IOException {

        FileOutputStream fileOutputStream = openFileOutput(fileName, Activity.MODE_PRIVATE);
        DataOutputStream dos = new DataOutputStream(fileOutputStream);
        dos.writeUTF(fxRate.getDate());
        dos.writeUTF(fxRate.getEuro());
        dos.writeUTF(fxRate.getDolar());
        dos.writeUTF(fxRate.getPound());
        dos.writeUTF(fxRate.getGold());
        dos.flush();
        fileOutputStream.close();
    }

    private FXRate readDataFromFile(String fileName) throws IOException {

        FileInputStream fileInputStream = openFileInput(fileName);
        DataInputStream dis = new DataInputStream(fileInputStream);
        String date = dis.readUTF();
        String euro = dis.readUTF();
        String dolar = dis.readUTF();
        String pound = dis.readUTF();
        String gold = dis.readUTF();
        FXRate fxRate = new FXRate(date, euro, dolar, pound, gold);
        fileInputStream.close();
        return fxRate;
    }
}