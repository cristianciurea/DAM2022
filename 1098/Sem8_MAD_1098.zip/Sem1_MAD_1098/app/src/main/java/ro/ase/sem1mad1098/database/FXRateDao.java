package ro.ase.sem1mad1098.database;

import java.util.List;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import ro.ase.sem1mad1098.FXRate;

@Dao
public interface FXRateDao {

    @Insert
    void insert(FXRate fxRate);

    @Delete
    void delete(FXRate fxRate);

    @Query("select * from fxrates")
    List<FXRate> getAllRates();

    @Update
    void update(FXRate fxRate);
}
