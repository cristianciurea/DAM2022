package ro.ase.sem1mad1098;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class CustomAdapter extends ArrayAdapter<Student> {

    private Context context;
    private int resource;
    private List<Student> studentList;
    private LayoutInflater layoutInflater;

    public CustomAdapter(@NonNull Context context, int resource,
                         List<Student> list, LayoutInflater layoutInflater) {
        super(context, resource, list);
        this.context = context;
        this.resource = resource;
        this.studentList = list;
        this.layoutInflater = layoutInflater;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        View view = layoutInflater.inflate(resource, parent, false);

        Student student = studentList.get(position);
        if(student!=null)
        {
            TextView tv1 = view.findViewById(R.id.tvName);
            tv1.setText(student.getStudentName());

            TextView tv2 = view.findViewById(R.id.tvBirthDate);
            tv2.setText(student.getBirthDate().toString());

            TextView tv3 = view.findViewById(R.id.tvFaculty);
            tv3.setText(student.getFaculty());

            TextView tv4 = view.findViewById(R.id.tvAverageGrade);
            tv4.setText(String.valueOf(student.getAverageGrade()));

            TextView tv5 = view.findViewById(R.id.tvYear);
            tv5.setText(student.getYearOfStudy());
        }

        return view;
    }
}
