package ro.ase.sem1mad1098.database;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;
import ro.ase.sem1mad1098.DateConverter;
import ro.ase.sem1mad1098.FXRate;
import ro.ase.sem1mad1098.Student;

@Database(entities = {FXRate.class, Student.class}, version = 2, exportSchema = false)
@TypeConverters({DateConverter.class})
public abstract class FXRatesDB extends RoomDatabase {

    public static final String DB_NAME = "fxrates.db";
    public static FXRatesDB instance;

    public static FXRatesDB getInstance(Context context)
    {
        if(instance == null)
            instance = Room.databaseBuilder(context, FXRatesDB.class, DB_NAME)
                    .allowMainThreadQueries()
                    .fallbackToDestructiveMigration()
                    .build();
        return instance;
    }

    public abstract FXRateDao getFXRatesDao();

    public abstract StudentsDao getStudentsDao();
}
