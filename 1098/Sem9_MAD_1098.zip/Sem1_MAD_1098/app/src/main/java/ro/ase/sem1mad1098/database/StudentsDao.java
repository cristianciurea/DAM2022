package ro.ase.sem1mad1098.database;

import java.util.List;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import ro.ase.sem1mad1098.Student;

@Dao
public interface StudentsDao {

    @Insert
    void insert(Student student);

    @Insert
    void insert(List<Student> studentList);

    @Query("select * from students")
    List<Student> getAllStudents();

    @Delete
    void delete(Student student);

    @Query("delete from students")
    void deleteAll();

    @Update
    void update(Student student);
}
