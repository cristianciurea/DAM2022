package ro.ase.sem1mad1098.network;

import android.os.AsyncTask;
import android.util.Log;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import ro.ase.sem1mad1098.FXRate;
import ro.ase.sem1mad1098.Student;

public class ExtractXML extends AsyncTask<URL, Void, InputStream> {

    InputStream ist = null;
    public List<Student> studentListXML;

    @Override
    protected InputStream doInBackground(URL... urls) {

        HttpURLConnection conn = null;

        try {
            conn = (HttpURLConnection)urls[0].openConnection();
            conn.setRequestMethod("GET");
            ist = conn.getInputStream();
            //parsing mechanism
            studentListXML = Parsing(ist);

        } catch (IOException e) {
            e.printStackTrace();
        }

        return ist;
    }

    public static Node getNodeByName(String nodeName, Node parentNode) throws Exception {

        if (parentNode.getNodeName().equals(nodeName)) {
            return parentNode;
        }

        NodeList list = parentNode.getChildNodes();
        for (int i = 0; i < list.getLength(); i++)
        {
            Node node = getNodeByName(nodeName, list.item(i));
            if (node != null) {
                return node;
            }
        }
        return null;
    }

    public static String getAttributeValue(Node node, String attrName) {
        try {
            return ((Element)node).getAttribute(attrName);
        }
        catch (Exception e) {
            return "";
        }
    }

    public List<Student> Parsing(InputStream ist)
    {
        List<Student> lista = new ArrayList<>();

        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        try {
            DocumentBuilder db = dbf.newDocumentBuilder();
            Document domDoc = db.parse(ist);
            domDoc.getDocumentElement().normalize();

            Node parinte = getNodeByName("Students", domDoc.getDocumentElement());
            if(parinte!=null)
            {
                NodeList listaCopii = parinte.getChildNodes();

                for(int i=0;i<listaCopii.getLength();i++)
                {
                    Node copil = listaCopii.item(i);
                    if(copil!=null && copil.getNodeName().equals("Student"))
                    {
                        Student student = new Student();

                        NodeList taguri = copil.getChildNodes();
                        for(int j=0;j<taguri.getLength();j++)
                        {
                            Node node = taguri.item(j);
                            Log.e("extract", node.getTextContent());

                            String atribut = getAttributeValue(node, "atribut");
                            if(atribut.equals("Name"))
                                student.setStudentName(node.getTextContent());
                            if(atribut.equals("BirthDate"))
                                student.setBirthDate(new Date(node.getTextContent()));
                            if(atribut.equals("Faculty"))
                                student.setFaculty(node.getTextContent());
                            if(atribut.equals("AverageGrade"))
                                student.setAverageGrade(Float.parseFloat(node.getTextContent()));
                            if(atribut.equals("YearStudy"))
                                student.setYearOfStudy(node.getTextContent());
                        }
                        lista.add(student);
                    }
                }
            }
            else
                Log.e("extract","parinte este null");

        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        } catch (SAXException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return lista;
    }
}
