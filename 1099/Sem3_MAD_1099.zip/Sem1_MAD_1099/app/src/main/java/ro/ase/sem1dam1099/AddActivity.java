package ro.ase.sem1dam1099;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

public class AddActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        String[] faculties = {"CSIE","REI","FABIZ","MRK"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(getApplicationContext(),
                android.support.constraint.R.layout.support_simple_spinner_dropdown_item,
                faculties);
        Spinner spinner = findViewById(R.id.spinner);
        spinner.setAdapter(adapter);

    }
}