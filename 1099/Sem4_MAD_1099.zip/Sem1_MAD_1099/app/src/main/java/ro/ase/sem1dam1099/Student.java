package ro.ase.sem1dam1099;

import java.io.Serializable;
import java.util.Date;

public class Student implements Serializable {

    private String studentName;
    private Date birthDate;
    private String faculty;//CSIE, REI, FABIZ
    private float averageGrade;
    private String yearOfStudy; //1st year, 2nd, 3rd

    public Student(String studentName, Date birthDate, String faculty, float averageGrade, String yearOfStudy) {
        this.studentName = studentName;
        this.birthDate = birthDate;
        this.faculty = faculty;
        this.averageGrade = averageGrade;
        this.yearOfStudy = yearOfStudy;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public Date getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(Date birthDate) {
        this.birthDate = birthDate;
    }

    public String getFaculty() {
        return faculty;
    }

    public void setFaculty(String faculty) {
        this.faculty = faculty;
    }

    public float getAverageGrade() {
        return averageGrade;
    }

    public void setAverageGrade(float averageGrade) {
        this.averageGrade = averageGrade;
    }

    public String getYearOfStudy() {
        return yearOfStudy;
    }

    public void setYearOfStudy(String yearOfStudy) {
        this.yearOfStudy = yearOfStudy;
    }

    @Override
    public String toString() {
        return "Student{" +
                "studentName='" + studentName + '\'' +
                ", birthDate=" + birthDate +
                ", faculty='" + faculty + '\'' +
                ", averageGrade=" + averageGrade +
                ", yearOfStudy='" + yearOfStudy + '\'' +
                '}';
    }
}
