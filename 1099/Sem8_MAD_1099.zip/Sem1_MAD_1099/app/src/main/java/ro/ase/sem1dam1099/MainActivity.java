package ro.ase.sem1dam1099;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import ro.ase.sem1dam1099.network.ExtractJSON;
import ro.ase.sem1dam1099.network.ExtractXML;

public class MainActivity extends AppCompatActivity {

    Intent intent;

    public static final int REQUEST_CODE_ADD = 200;

    public static final int REQUEST_CODE_EDIT = 300;

    public static final String EDIT_STUDENT = "editStudent";

    public int poz;

    List<Student> studentsList = new ArrayList<>();

    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FloatingActionButton btn = findViewById(R.id.floatingActionButton);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), AddActivity.class);
                startActivityForResult(intent, REQUEST_CODE_ADD);
            }
        });

        listView = findViewById(R.id.listView);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {

                poz = position;
                intent = new Intent(getApplicationContext(), AddActivity.class);
                intent.putExtra(EDIT_STUDENT, studentsList.get(position));
                startActivityForResult(intent, REQUEST_CODE_EDIT);
            }
        });

        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int position, long id) {

                Student student = studentsList.get(position);
                CustomAdapter adapter = (CustomAdapter) listView.getAdapter();

                AlertDialog dialog = new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Delete confirmation")
                        .setMessage("Are you sure to delete?")
                        .setNegativeButton("NO", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Toast.makeText(getApplicationContext(),
                                        "We didn't delete!", Toast.LENGTH_LONG).show();
                                dialogInterface.cancel();
                            }
                        })
                        .setPositiveButton("YES", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                studentsList.remove(student);
                                adapter.notifyDataSetChanged();
                                dialogInterface.cancel();
                            }
                        })
                        .create();

                dialog.show();

                return true;
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode== REQUEST_CODE_ADD && resultCode==RESULT_OK && data!=null)
        {
            Student student = (Student) data.getSerializableExtra(AddActivity.ADD_STUDENT);
            if(student!=null)
            {
                studentsList.add(student);
                /*ArrayAdapter<Student> adapter2 = new ArrayAdapter<>(getApplicationContext(),
                        android.R.layout.simple_list_item_1, studentsList);*/
                CustomAdapter adapter2 = new CustomAdapter(getApplicationContext(),
                        R.layout.elem_listview, studentsList, getLayoutInflater())
                {
                    @NonNull
                    @Override
                    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                        View view = super.getView(position, convertView, parent);

                        Student student1 = studentsList.get(position);

                        TextView tvGrade = view.findViewById(R.id.tvAverageGrade);
                        if(student1.getAverageGrade() >= 5)
                            tvGrade.setTextColor(Color.GREEN);
                        else
                            tvGrade.setTextColor(Color.RED);

                        return view;
                    }
                };
                listView.setAdapter(adapter2);
            }
        }
        else
        if(requestCode== REQUEST_CODE_EDIT && resultCode==RESULT_OK && data!=null)
        {
            Student student = (Student) data.getSerializableExtra(AddActivity.ADD_STUDENT);
            if(student!=null)
            {
               studentsList.get(poz).setStudentName(student.getStudentName());
               studentsList.get(poz).setBirthDate(student.getBirthDate());
               studentsList.get(poz).setFaculty(student.getFaculty());
               studentsList.get(poz).setAverageGrade(student.getAverageGrade());
               studentsList.get(poz).setYearOfStudy(student.getYearOfStudy());

                /*ArrayAdapter<Student> adapter2 = new ArrayAdapter<>(getApplicationContext(),
                        android.R.layout.simple_list_item_1, studentsList);*/
                CustomAdapter adapter2 = new CustomAdapter(getApplicationContext(),
                        R.layout.elem_listview, studentsList, getLayoutInflater())
                {
                    @NonNull
                    @Override
                    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                        View view = super.getView(position, convertView, parent);

                        Student student1 = studentsList.get(position);

                        TextView tvGrade = view.findViewById(R.id.tvAverageGrade);
                        if(student1.getAverageGrade() >= 5)
                            tvGrade.setTextColor(Color.GREEN);
                        else
                            tvGrade.setTextColor(Color.RED);

                        return view;
                    }
                };
                listView.setAdapter(adapter2);
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId())
        {
            case R.id.option1:
                Intent intent1 = new Intent(this, NBRActivity.class);
                startActivity(intent1);
                break;
            case R.id.option2:

                ExtractXML extractXML = new ExtractXML()
                {
                    @Override
                    protected void onPostExecute(InputStream inputStream) {

                        studentsList.addAll(this.studentList);

                        CustomAdapter adapter2 = new CustomAdapter(getApplicationContext(),
                                R.layout.elem_listview, studentsList, getLayoutInflater())
                        {
                            @NonNull
                            @Override
                            public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                                View view = super.getView(position, convertView, parent);

                                Student student1 = studentsList.get(position);

                                TextView tvGrade = view.findViewById(R.id.tvAverageGrade);
                                if(student1.getAverageGrade() >= 5)
                                    tvGrade.setTextColor(Color.GREEN);
                                else
                                    tvGrade.setTextColor(Color.RED);

                                return view;
                            }
                        };
                        listView.setAdapter(adapter2);
                    }
                };
                try {
                    extractXML.execute(new URL("https://pastebin.com/raw/e81dYpYM"));
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                }

                break;
            case R.id.option3:

                ExtractJSON extractJSON = new ExtractJSON(){

                    @Override
                    protected void onPostExecute(String s) {

                        studentsList.addAll(studentListJSON);

                        CustomAdapter adapter2 = new CustomAdapter(getApplicationContext(),
                                R.layout.elem_listview, studentsList, getLayoutInflater())
                        {
                            @NonNull
                            @Override
                            public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                                View view = super.getView(position, convertView, parent);

                                Student student1 = studentsList.get(position);

                                TextView tvGrade = view.findViewById(R.id.tvAverageGrade);
                                if(student1.getAverageGrade() >= 5)
                                    tvGrade.setTextColor(Color.GREEN);
                                else
                                    tvGrade.setTextColor(Color.RED);

                                return view;
                            }
                        };
                        listView.setAdapter(adapter2);
                    }
                };
                try {
                    extractJSON.execute(new URL("https://pastebin.com/raw/cFHiKfNj"));
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                }

                return true;
        }
        return false;
    }
}