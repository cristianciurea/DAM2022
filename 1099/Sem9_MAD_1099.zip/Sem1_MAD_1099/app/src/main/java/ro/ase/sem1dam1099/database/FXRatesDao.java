package ro.ase.sem1dam1099.database;

import java.util.List;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import ro.ase.sem1dam1099.FXRate;

@Dao
public interface FXRatesDao {

    @Insert
    void insert(FXRate fxRate);

    @Delete
    void delete(FXRate fxRate);

    @Update
    void update(FXRate fxRate);

    @Query("select * from fxrates")
    List<FXRate> getAllRates();
}
