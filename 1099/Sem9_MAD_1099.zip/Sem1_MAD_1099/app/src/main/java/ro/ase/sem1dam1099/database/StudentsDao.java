package ro.ase.sem1dam1099.database;

import java.util.List;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import ro.ase.sem1dam1099.Student;

@Dao
public interface StudentsDao {

    @Insert
    void insert(Student student);

    @Insert
    void insert(List<Student> studentList);

    @Update
    void update(Student student);

    @Delete
    void delete(Student student);

    @Query("select * from students")
    List<Student> getAllStudents();

    @Query("delete from students")
    void deleteAll();
}
