package ro.ase.semdam1080;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AddActivity extends AppCompatActivity {

    public static final String ADD_STUDENT = "addStudent";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        Intent intent = getIntent();

        String[] facultati = {"CSIE", "CIG", "FABIZ", "REI"};
        ArrayAdapter<String> adaptor = new ArrayAdapter<>(getApplicationContext(),
                android.support.design.R.layout.support_simple_spinner_dropdown_item,
                facultati);
        Spinner spinner = findViewById(R.id.spinner);
        spinner.setAdapter(adaptor);

        EditText etNume = findViewById(R.id.editTextNumeStudent);
        EditText etData = findViewById(R.id.editTextDate);
        EditText etMedie = findViewById(R.id.editTextMedie);
        RadioGroup radioGroup = findViewById(R.id.radioGroup);

        if(intent.hasExtra(MainActivity.EDIT_STUDENT))
        {
            Student student = (Student) intent.getSerializableExtra(MainActivity.EDIT_STUDENT);
            etNume.setText(student.getNumeStudent());
            etData.setText(new SimpleDateFormat("MM/dd/yyyy", Locale.US).
                    format(student.getDataNasterii()));
            ArrayAdapter<String> adapter = (ArrayAdapter<String>) spinner.getAdapter();
            for(int i=0;i<adapter.getCount();i++)
                if(adapter.getItem(i).equals(student.getFacultate()))
                {
                    spinner.setSelection(i);
                    break;
                }
            etMedie.setText(student.getMedieAnuala()+"");
            if(student.getAnStudiu().equals("1"))
                radioGroup.check(R.id.radioButton1);
            else
            if(student.getAnStudiu().equals("2"))
                radioGroup.check(R.id.radioButton2);
            else
            if(student.getAnStudiu().equals("3"))
                radioGroup.check(R.id.radioButton3);
        }

        Button btnCreare = findViewById(R.id.btnCreare);

        if(intent.hasExtra(MainActivity.EDIT_STUDENT))
            btnCreare.setText("Editare student");

        btnCreare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(etNume.getText().toString().isEmpty())
                    etNume.setError("Introduceti numele!");
                else
                    if(etData.getText().toString().equals(""))
                        etData.setError("Introduceti data nasterii!");
                    else
                        if(etMedie.getText().toString().isEmpty())
                            etMedie.setError("Introduceti media!");
                        else
                        {
                            SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy", Locale.US);
                            try
                            {
                                sdf.parse(etData.getText().toString());
                                Date dataNasterii = new Date(etData.getText().toString());
                                String numeStudent = etNume.getText().toString();
                                String facultate = spinner.getSelectedItem().toString();
                                float medie = Float.parseFloat(etMedie.getText().toString());
                                RadioButton radioButton = findViewById(radioGroup.getCheckedRadioButtonId());
                                String anStudiu = radioButton.getText().toString();

                                Student student = new Student(numeStudent, dataNasterii, facultate,
                                        medie, anStudiu);
                                /*Toast.makeText(getApplicationContext(), student.toString(),
                                        Toast.LENGTH_LONG).show();*/
                                intent.putExtra(ADD_STUDENT, student);
                                setResult(RESULT_OK, intent);
                                finish();
                            }
                            catch (Exception ex)
                            {
                                ex.printStackTrace();
                                Toast.makeText(getApplicationContext(), "Data invalida!",
                                        Toast.LENGTH_LONG).show();
                            }
                        }
            }
        });
    }
}