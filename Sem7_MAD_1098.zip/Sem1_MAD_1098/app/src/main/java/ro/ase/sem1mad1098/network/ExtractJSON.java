package ro.ase.sem1mad1098.network;

import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import ro.ase.sem1mad1098.Student;

public class ExtractJSON extends AsyncTask<URL, Void, String> {

    public List<Student> studentListJSON = new ArrayList<>();

    @Override
    protected String doInBackground(URL... urls) {

        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) urls[0].openConnection();
            conn.setRequestMethod("GET");
            InputStream ist = conn.getInputStream();

            InputStreamReader isr = new InputStreamReader(ist);
            BufferedReader br = new BufferedReader(isr);
            String line = null;
            String result = "";
            while ((line = br.readLine())!=null)
                result += line;

            //parsing mechanism
            parseJSON(result);

            return result;

        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

    public void parseJSON(String str)
    {
        if(str!=null)
        {
            JSONObject jsonObject = null;

            try {
                jsonObject = new JSONObject(str);

                JSONArray students = jsonObject.getJSONArray("students");
                for(int i=0;i<students.length();i++)
                {
                    JSONObject object = students.getJSONObject(i);

                    String name = object.getString("Name");
                    Date birthDate = new Date(object.getString("BirthDate"));
                    String faculty = object.getString("Faculty");
                    float averageGrade = Float.parseFloat(object.getString("AverageGrade"));
                    String yearStudy = object.getString("YearStudy");

                    Student student = new Student(name, birthDate, faculty, averageGrade, yearStudy);
                    studentListJSON.add(student);
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        else
            Log.e("parseJSON", "JSON string is null!");
    }
}
